package pt.iscte.iul;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.text.diff.CommandVisitor;


// Source : https://itsallbinary.com/compare-files-side-by-side-and-hightlight-diff-using-java-apache-commons-text-diff-myers-algorithm/


public class FileCommandsVisitor implements CommandVisitor<Character> {

	// Spans with red & green highlights to put highlighted characters in HTML
	private static final String DELETION = "<span style=\"background-color: #FB504B\">${text}</span>";
	private static final String INSERTION = "<span style=\"background-color: #45EA85\">${text}</span>";

	private String left = "";
	private String right = "";

	/**
	 * This method purpose is to translate "<" and ">" characters so as to avoid
	 * HTML mistakes. i.e. HTML reads those characters as actual HTML tags.
	 * @param c : verifies character c (for "<" and ">" types)
	 * @return String : if its the case, returns HTML entities (&lt or &gt).
	 */
	private String escapeStr(Character c) { 
		switch(c.charValue()) {
		case '<' : return "&lt;";
		case '>' : return "&gt;";
		}
		return c.toString();
	}


	/**
	 * 	If character is newline("\n"), transforms into HTML's <br>
	 *  If not, character c is present in both file versions, add to both :
	 *   we don't have to  highlight the character in the HTML file.
	 */
	public void visitKeepCommand(Character c) {
		String toAppend = "\n".equals("" + c) ? "<br/>" : "" + escapeStr(c);
		left = left + toAppend;
		right = right + toAppend;
	}

	
	/**
	 * 	If character is newline("\n"), transforms into HTML's <br>
	 *  If not, character c is present on right file, but not the left : 
	 *  show green highlight on right file character.
	 */
	public void visitInsertCommand(Character c) {
		String toAppend = "\n".equals("" + c) ? "<br/>" : "" + escapeStr(c);
		right = right + INSERTION.replace("${text}", "" + toAppend);
	}

	

	/**
	 * 	If character is newline("\n"), transforms into HTML's <br>
	 *  If not, character c is present on left file, but not the right : 
	 *  show red highlight on left file character.
	 */
	public void visitDeleteCommand(Character c) {
		String toAppend = "\n".equals("" + c) ? "<br/>" : "" + escapeStr(c);
		left = left + DELETION.replace("${text}", "" + toAppend);
	}

	
	/**
	 * Get template (difftemplate.html) and replace placeholders with left
	 * and right variables. i.e. the actual comparison.
	 * Writes the HTML in disk, under the application directory.
	 */
	public void generateHTML() throws IOException {

		// Get template & replace placeholders with left & right variables with actual
		// comparison
		String template = FileUtils.readFileToString(new File("difftemplate.html"), "utf-8");
		String firstOutput = template.replace("${left}", left);
		String secondOutput = firstOutput.replace("${right}", right);
		// Write file to disk.
		FileUtils.write(new File("finalDiff.html"), secondOutput, "utf-8"); //can change path easily
		System.out.println("HTML diff generated.");
	}
}




