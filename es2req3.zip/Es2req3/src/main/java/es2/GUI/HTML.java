package es2.GUI;

import java.io.File;
import java.util.List;

public class HTML {

	public static String array2HTML(Object[][] array, List<File> fileList){
		StringBuilder html = new StringBuilder(
				"<table BORDER>");
		html.append("<thead><th>" + "Article Title" + "</th><th>" + "Journal Name" + "</th><th>" + "Publication year" + "</th><th>" + "Authors" + "</th></thead>");
		int j=0;
		int x=0;
		for(int i = 0; i < array.length; i++){
			Object[] row = array[i];
			html.append("<tr>");
			for(Object elem:row){
				
				if(j==0 || j%4==0) {
					html.append("<td><a href=http://localhost:8000/wp-content/uploads/2020/06/"+fileList.get(x).getName()+">" + elem.toString() + "</a></td>");
					x++;
				}
				else
					html.append("<td>" + elem.toString() + "</td>");
				j++;
			}
			html.append("</tr>");
		}
		html.append("</table>");
		return html.toString();
	}
}
