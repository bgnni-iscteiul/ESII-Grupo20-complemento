import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.util.List;

import org.junit.Test;

import es2.GUI.HTML;
import es2.GUI.Main;

public class HTMLAndMainTest {
	
	@Test
	public void test() {
		Main m = new Main("test");
		assertNotNull(m);
		assertNotNull(m.getData());
		assertNotNull(m.getFileList());
		Object[][] data=m.getData();
		List<File> fileList=m.getFileList();
		assertEquals("<table BORDER><thead><th>Article Title</th><th>Journal Name</th><th>Publication year</th><th>Authors</th></thead><tr><td><a href=http://localhost:8000/wp-content/uploads/2020/06/1-s2.0-S1755436517301135-main.pdf>Modelling the global spread of diseases: A review of current practice and capability</a></td><td>Epidemics</td><td>2018</td><td>Caroline E. Walters, Margaux M.I. Mesl�, Ian M. Hall</td></tr><tr><td><a href=http://localhost:8000/wp-content/uploads/2020/06/178-1-53.pdf>Pandemic versus Epidemic Influenza Mortality: A Pattern of Changing Age Distribution</a></td><td>The Journal of Infectious Diseases</td><td>1998</td><td>Lone Simonsen, Matthew J. Clarke, Lawrence B. Schonberger, Nancy H. Arden, Nancy J. Cox, Keiji Fukuda</td></tr><tr><td><a href=http://localhost:8000/wp-content/uploads/2020/06/biology-09-00094.pdf>Temperature Decreases Spread Parameters of the New Covid-19 Case Dynamics</a></td><td>Biology</td><td>2020</td><td>Jacques Demongeot, Yannis Flet-Berliac, Herv� Seligmann</td></tr><tr><td><a href=http://localhost:8000/wp-content/uploads/2020/06/biology-09-00097.pdf>Using Early Data to Estimate the Actual Infection Fatality Ratio from COVID-19 in France</a></td><td>Biology</td><td>2020</td><td>Lionel Roques, Etienne K Klein, Julien Papa�x, Antoine Sar, Samuel Soubeyrand</td></tr></table>",HTML.array2HTML(data, fileList));
	}
	

}
