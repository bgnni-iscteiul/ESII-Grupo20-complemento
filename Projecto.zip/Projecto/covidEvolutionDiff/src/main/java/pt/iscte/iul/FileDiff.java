package pt.iscte.iul;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.text.diff.StringsComparator;


//Source : https://itsallbinary.com/compare-files-side-by-side-and-hightlight-diff-using-java-apache-commons-text-diff-myers-algorithm/


public class FileDiff {

	/**
	 * Gets the differences between both files that we want to compare.
	 * In case both files have different number of lines, fill in with empty
	 * strings. Append newline char at the end, so that the next line comparison moves on to
	 * next line.
	 * @throws IOException
	 */
	public void getDifferences() throws IOException {
		// Compares both files fetched with GitFetcher, reads them with line iterator, 
		LineIterator file1 = FileUtils.lineIterator(new File("/tmp/covid19spreading.rdf.1"), "utf-8");
		LineIterator file2 = FileUtils.lineIterator(new File("/tmp/covid19spreading.rdf.2"), "utf-8");

		FileCommandsVisitor fileCommandsVisitor = new FileCommandsVisitor();

		// Read file line by line so that comparison can be done line by line.
		while (file1.hasNext() || file2.hasNext()) {
			String left = (file1.hasNext() ? file1.nextLine() : "") + "\n";
			String right = (file2.hasNext() ? file2.nextLine() : "") + "\n";

			// Prepare diff comparator with lines from both files.
			StringsComparator comparator = new StringsComparator(left, right);

			if (comparator.getScript().getLCSLength() > (Integer.max(left.length(), right.length()) * 0.4)) {
				/*
				 * If both lines have atleast 40% commonality then only compare with each other
				 * so that they are aligned with each other in final diff HTML.
				 */
				comparator.getScript().visit(fileCommandsVisitor);
			} else {
				/*
				 * If both lines do not have 40% commanlity then compare each with empty line so
				 * that they are not aligned to each other in final diff instead they show up on
				 * separate lines.
				 */
				StringsComparator leftComparator = new StringsComparator(left, "\n");
				leftComparator.getScript().visit(fileCommandsVisitor);
				StringsComparator rightComparator = new StringsComparator("\n", right);
				rightComparator.getScript().visit(fileCommandsVisitor);
			}
		}

		fileCommandsVisitor.generateHTML();
	}
}





