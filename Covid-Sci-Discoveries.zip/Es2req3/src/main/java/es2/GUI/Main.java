package es2.GUI;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.LinkedList;
import java.util.List;

import pl.edu.icm.cermine.ContentExtractor;
import pl.edu.icm.cermine.metadata.model.DateType;
import pl.edu.icm.cermine.metadata.model.DocumentMetadata;

public class Main {

	private int numbOfFiles=0;
	private String directoryPath;
	private static List<File> fileList = new LinkedList<File>();
	private static Object[][] data;

	public Main(String type) {
		if(type.equals("test"))
			directoryPath=System.getProperty("user.dir");
		else
			directoryPath="C:\\Users\\bingu\\wordpress\\wordpress\\wp-content\\uploads\\Covid-19 Scientific Articles";
		countAndAcceptFiles();
		data = new Object[numbOfFiles][4];
		setContent();
	}

	private void countAndAcceptFiles() { 
		File[] files = new File(directoryPath).listFiles(new FileFilter() {
			public boolean accept(File pathname) {
				if(pathname.getName().endsWith(".pdf"))
					return true;
				return false;
			}
		});
		for (File file : files) {
			fileList.add(file);
		}
		numbOfFiles=files.length;
	}

	private void setContent() {
		int i=0;

		for (File file : fileList) {
			try {
				ContentExtractor extractor = new ContentExtractor();
				String path = file.getAbsolutePath();
				InputStream inputStream = new FileInputStream(path);
				extractor.setPDF(inputStream);
				DocumentMetadata result=extractor.getMetadata();
				getData(result, i);
				i++;
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void getData(DocumentMetadata result, int i) {
		data[i][0] = result.getTitle();
		data[i][1] = result.getJournal();
		data[i][2] = result.getDate(DateType.PUBLISHED).getYear();
		if(result.getAuthors().size()== 1) {
			data[i][3] = result.getAuthors().get(0).getName();
		}
		else {
			String authors="";
			String authorsNames="";
			for(int j = 0; j<result.getAuthors().size(); j++)
				authors+= result.getAuthors().get(j).getName()+ ", ";
			if(authors.endsWith(", "))
				authorsNames=authors.substring(0, authors.length()-2);
			data[i][3] = authorsNames;
		}
	}
	
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		Main m = new Main("");
		System.out.println(HTML.array2HTML(data, fileList));
	}

	public Object[][] getData() {
		return data;
	}
	
	public List<File> getFileList(){
		return fileList;
	}
}
