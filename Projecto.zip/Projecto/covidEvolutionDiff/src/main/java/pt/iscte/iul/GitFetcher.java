package pt.iscte.iul;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.ListTagCommand;
import org.eclipse.jgit.api.errors.CheckoutConflictException;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRefNameException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.RefAlreadyExistsException;
import org.eclipse.jgit.api.errors.RefNotFoundException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.errors.AmbiguousObjectException;
import org.eclipse.jgit.errors.IncorrectObjectTypeException;
import org.eclipse.jgit.errors.MissingObjectException;
import org.eclipse.jgit.errors.RevisionSyntaxException;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;

/**
 * 	The GitFetcher program implements an application (covid-evolution-diff) that fetches 
 * 	the file (covid19spreading.rdf) within the last 2 commits referred by a tag,
 *  from Git.
 *  After getting both versions of the file, we compare and display them, by creating
 *  a HTML file with the differences highlighted in color.
 * 
 * @author Tomas Ferreira
 * @version 1.0
 */

public class GitFetcher {


	private static final String REMOTE_URL = "https://github.com/vbasto-iscte/ESII1920.git";
	private static final String LOCAL_PATH = "/home/tomas/BU/backup/UNI/ISCTE/6_Semestre/ES2/ES21920";

	private Git git; 

	// tag names to be filled by fillTagNames method
	private String latestTagName;
	private String secondLatestTagName;



	/**
	 *  Before all, this method clones the desired repository (defined by REMOTE_URL).
	 *  After that, it gets the names of the last 2 tags available in git.
	 *  Finally, it checkout's each of the last 2 tags, and saves both files in
	 *  the /tmp directory for future comparison (using FileDiff class).
	 */
	public void fetchFilesFromGit() throws RevisionSyntaxException, InvalidRemoteException, TransportException, AmbiguousObjectException, IncorrectObjectTypeException, GitAPIException, IOException {
		cloneRepository();
		fillTagNames();
		checkout();
	}

	/**
	 *	 Before anything, this method deletes the directory used to store the git clone.
	 *	 That way, every time we run the program, we don't have to worry about non empty folder errors.
	 *	 After emptying the directory, we can save the git clone to that same directory, which
	 *	 path is defined by LOCAL_PATH.
	 */

	private void cloneRepository() throws InvalidRemoteException, TransportException, GitAPIException, RevisionSyntaxException, AmbiguousObjectException, IncorrectObjectTypeException, IOException {
		FileUtils.deleteDirectory(new File(LOCAL_PATH)); 

		git = Git.cloneRepository()
				.setURI(REMOTE_URL)
				.setCredentialsProvider(new UsernamePasswordCredentialsProvider("tgsfa-iscteiul", "UDF1HZANtomas1997"))
				.setDirectory(new File(LOCAL_PATH))
				.call();
	}



	/**
	 * 	This method sole purpose is to fill in the names of the latest and second
	 * 	latest git tag's.
	 * 
	 * 	Firstly, we call the tagList method, returning a list of Refs. With those
	 * 	Refs, we can get the names of all the tags (not just the latest two).
	 * 	Lastly, since the list of Refs organizes by oldest tags first, we add
	 * 	all the tags to a linked list, and get the last 2 list positions, which 
	 * 	corresponds to the newest tags.
	 */
	private void fillTagNames() throws GitAPIException, IOException {
		ListTagCommand listTagCommand =  git.tagList();
		List<Ref> listTag = listTagCommand.call();
		LinkedList<String> listOfAllTagNames = new LinkedList<String>();

		for(Ref tag : listTag) 
			listOfAllTagNames.add(tag.getName());	 

		if(listOfAllTagNames.size() < 2)
			System.out.println("Nao existem pelo menos duas tags");
		else {
			int lastTagPosition = listOfAllTagNames.size()-1;
			latestTagName = listOfAllTagNames.remove(lastTagPosition);
			secondLatestTagName = listOfAllTagNames.remove(lastTagPosition-1);
		}
		System.out.println("Latest tags: " + latestTagName + " " + secondLatestTagName);
	}


	/**
	 * 	This method purpose is to checkout both tags.
	 * 	Since we have already fetched the last 2 tags names, in the method above,
	 * 	we can now checkout both of them by their names, and save both file versions
	 * 	in /tmp directory for future comparison.
	 */
	private void checkout() throws RefAlreadyExistsException, RefNotFoundException, InvalidRefNameException, CheckoutConflictException, GitAPIException {

		git.checkout().setName(latestTagName).call();
		File file1 = new File(LOCAL_PATH + "/" + "covid19spreading.rdf");
		file1.renameTo(new File("/tmp/covid19spreading.rdf.1"));

		git.checkout().setName(secondLatestTagName).call();
		File file2 = new File(LOCAL_PATH + "/" + "covid19spreading.rdf");
		file2.renameTo(new File("/tmp/covid19spreading.rdf.2"));

		git.close();
	}








	public static void main( String[] args ) throws RevisionSyntaxException, MissingObjectException, IncorrectObjectTypeException, AmbiguousObjectException, IOException, InvalidRemoteException, TransportException, GitAPIException {
		// Runs GitFetcher first, which gets the last 2 file versions (with tags) and
		// stores them in /tmp direcotry. 
		new GitFetcher().fetchFilesFromGit();
		
		// After that, run FileDiff, which compares both files stored in /tmp directory,
		// and generates HTML highlighting the differences. 
		new FileDiff().getDifferences();
	}

	public Git getGit() {
		return git;
	}

}


